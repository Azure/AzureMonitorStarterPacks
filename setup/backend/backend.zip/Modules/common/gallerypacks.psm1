# This module has functions to manage packs that have gallery components
# How to find if a pack has a gallery component? Maybe gallery applications have tags.
# When adding the tag an creating associated mappings, we need to check if there is an application in the gallery with the same tag.
# If so, also install the application in the VM.
